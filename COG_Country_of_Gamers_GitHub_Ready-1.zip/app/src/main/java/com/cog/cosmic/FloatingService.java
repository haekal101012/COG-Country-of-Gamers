package com.cog.cosmic;

import android.app.*; import android.content.*; import android.graphics.Color; import android.graphics.drawable.GradientDrawable; import android.os.*; import android.provider.Settings; import android.view.*; import android.widget.*; import java.util.*;

public class FloatingService extends Service {
 private WindowManager wm; private FrameLayout bubble; private LinearLayout panel; private CrosshairView crosshair; private WindowManager.LayoutParams bp,pp,cp; private float dx,dy; private int purple=Color.rgb(124,92,255);
 int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);} TextView tv(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
 GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;}
 @Override public IBinder onBind(Intent i){return null;}
 @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);showBubble(); showCrosshair();}
 private int type(){return Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;}
 private WindowManager.LayoutParams lp(int w,int h){return new WindowManager.LayoutParams(dp(w),dp(h),type(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,-3);}
 void showBubble(){ bubble=new FrameLayout(this); TextView b=tv("COG",14,Color.WHITE);b.setGravity(Gravity.CENTER); bubble.setBackground(bg(purple,30)); bubble.addView(b,new FrameLayout.LayoutParams(dp(58),dp(58)));
  bp=lp(58,58);bp.gravity=Gravity.TOP|Gravity.START;bp.x=dp(16);bp.y=dp(180); wm.addView(bubble,bp);
  bubble.setOnTouchListener(new View.OnTouchListener(){float sx,sy,ox,oy;long down;public boolean onTouch(View v,android.view.MotionEvent e){if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();ox=bp.x;oy=bp.y;down=System.currentTimeMillis();return true;}if(e.getAction()==2){bp.x=(int)(ox+e.getRawX()-sx);bp.y=(int)(oy+e.getRawY()-sy);wm.updateViewLayout(bubble,bp);return true;}if(e.getAction()==1){if(System.currentTimeMillis()-down<250)togglePanel();return true;}return true;}});
 }
 void togglePanel(){if(panel==null)showPanel();else{wm.removeView(panel);panel=null;}}
 void showCrosshair(){
  crosshair=new CrosshairView(this);
  cp=new WindowManager.LayoutParams(-1,-1,type(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,-3);
  cp.gravity=Gravity.TOP|Gravity.START;
  wm.addView(crosshair,cp);
 }
 void setCrosshair(boolean on){if(crosshair!=null){crosshair.enabled=on;crosshair.invalidate();}}
 void showPanel(){
  panel=new LinearLayout(this);panel.setOrientation(LinearLayout.HORIZONTAL);panel.setPadding(dp(10),dp(10),dp(10),dp(10));panel.setBackground(bg(Color.rgb(13,19,35),24));
  LinearLayout side=new LinearLayout(this);side.setOrientation(LinearLayout.VERTICAL);side.setPadding(dp(8),dp(8),dp(8),dp(8));side.setBackground(bg(Color.rgb(9,14,27),18));
  TextView logo=tv("COG\nCOUNTRY OF\nGAMERS",11,Color.WHITE);logo.setTypeface(null,1);logo.setGravity(Gravity.CENTER);side.addView(logo,new LinearLayout.LayoutParams(dp(86),dp(82)));
  String[] nav={"⌂  Dashboard","⚙  Controls","▣  Macros","◈  Profiles"}; for(String n:nav){TextView x=tv(n,12,Color.LTGRAY);x.setPadding(dp(7),0,0,0);side.addView(x,new LinearLayout.LayoutParams(dp(86),dp(48)));}
  TextView status=tv("● ACTIVE",11,Color.rgb(55,240,166));status.setGravity(Gravity.CENTER);side.addView(status,new LinearLayout.LayoutParams(dp(86),dp(45)));panel.addView(side,new LinearLayout.LayoutParams(dp(104),-1));
  LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(14),dp(5),dp(8),0);
  TextView head=tv("Performance Controls",19,Color.WHITE);head.setTypeface(null,1);content.addView(head,new LinearLayout.LayoutParams(-1,dp(45)));
  TextView sub=tv("Fine-tune your control profile",11,Color.rgb(140,150,175));content.addView(sub,new LinearLayout.LayoutParams(-1,dp(25)));
  addSeek(content,"Sensi Scale",75); addSeek(content,"Kelicinan / Smoothness",60); addSeek(content,"Response Rate",82); addSeek(content,"Deadzone",10);
  LinearLayout presets=new LinearLayout(this);presets.setOrientation(LinearLayout.HORIZONTAL); String[] p={"LOW","MEDIUM","HIGH","CUSTOM"}; for(String s:p){TextView q=tv(s,10,Color.WHITE);q.setGravity(Gravity.CENTER);q.setBackground(bg(s.equals("CUSTOM")?purple:Color.rgb(28,38,62),12));LinearLayout.LayoutParams z=new LinearLayout.LayoutParams(0,dp(38),1);z.setMargins(3,3,3,3);presets.addView(q,z);}content.addView(presets,new LinearLayout.LayoutParams(-1,dp(48)));
  TextView cross=tv("🎯  CROSSHAIR   ON",13,Color.WHITE);cross.setGravity(Gravity.CENTER_VERTICAL);cross.setPadding(dp(12),0,0,0);cross.setBackground(bg(Color.rgb(22,31,51),14));cross.setOnClickListener(v->{if(crosshair!=null){crosshair.enabled=!crosshair.enabled;cross.setText(crosshair.enabled?"🎯  CROSSHAIR   ON":"🎯  CROSSHAIR   OFF");setCrosshair(crosshair.enabled);}});content.addView(cross,new LinearLayout.LayoutParams(-1,dp(46)));
  TextView crossInfo=tv("Visual overlay only • adjustable size in source",10,Color.rgb(145,155,180));content.addView(crossInfo,new LinearLayout.LayoutParams(-1,dp(24)));
  TextView macro=tv("Macro Manager",16,Color.WHITE);macro.setTypeface(null,1);content.addView(macro,new LinearLayout.LayoutParams(-1,dp(42)));
  TextView m=tv("●  Utility slots\n   Macro UI only — no automated game input",11,Color.rgb(160,170,195));m.setPadding(dp(12),0,0,0);m.setBackground(bg(Color.rgb(22,31,51),14));content.addView(m,new LinearLayout.LayoutParams(-1,dp(62)));
  TextView close=tv("×",26,Color.WHITE);close.setGravity(Gravity.CENTER);close.setOnClickListener(v->togglePanel());content.addView(close,new LinearLayout.LayoutParams(-1,dp(42)));
  panel.addView(content,new LinearLayout.LayoutParams(0,-1,1));
  pp=lp(370,520);pp.gravity=Gravity.TOP|Gravity.START;pp.x=dp(12);pp.y=dp(120);wm.addView(panel,pp);
  panel.setOnTouchListener(new View.OnTouchListener(){float sx,sy,ox,oy;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();ox=pp.x;oy=pp.y;return true;}if(e.getAction()==2){pp.x=(int)(ox+e.getRawX()-sx);pp.y=(int)(oy+e.getRawY()-sy);wm.updateViewLayout(panel,pp);return true;}return true;}});
 }
 void addSeek(LinearLayout c,String label,int val){TextView l=tv(label+"   "+val+"%",12,Color.WHITE);c.addView(l,new LinearLayout.LayoutParams(-1,dp(26)));SeekBar s=new SeekBar(this);s.setProgress(val);s.setMax(100);s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){l.setText(label+"   "+p+"%");}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});c.addView(s,new LinearLayout.LayoutParams(-1,dp(34)));}
 @Override public void onDestroy(){if(bubble!=null)wm.removeView(bubble);if(panel!=null)wm.removeView(panel);if(crosshair!=null)wm.removeView(crosshair);super.onDestroy();}
 static class CrosshairView extends View { boolean enabled=true; PaintHolder ph=new PaintHolder(); CrosshairView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
  protected void onDraw(android.graphics.Canvas c){super.onDraw(c);if(!enabled)return;float x=getWidth()/2f,y=getHeight()/2f;android.graphics.Paint p=ph.p;p.setStyle(android.graphics.Paint.Style.STROKE);p.setStrokeWidth(3f);p.setColor(Color.rgb(0,245,220));p.setStrokeCap(android.graphics.Paint.Cap.SQUARE);float r=18f,g=8f; c.drawLine(x-r-g,y,x-g,y,p);c.drawLine(x+g,y,x+r+g,y,p);c.drawLine(x,y-r-g,x,y-g,p);c.drawLine(x,y+g,x,y+r+g,p);p.setStyle(android.graphics.Paint.Style.FILL);c.drawCircle(x,y,2.5f,p);}
  static class PaintHolder {android.graphics.Paint p=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);}
 }
}
