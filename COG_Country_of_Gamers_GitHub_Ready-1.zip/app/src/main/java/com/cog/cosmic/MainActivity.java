package com.cog.cosmic;

import android.app.*; import android.os.*; import android.content.*; import android.graphics.Color; import android.net.Uri; import android.provider.Settings; import android.view.*; import android.widget.*;

public class MainActivity extends Activity {
  private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
  @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(8,11,22));
    LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(24),dp(30),dp(24),dp(24)); root.setBackgroundColor(Color.rgb(8,11,22));
    TextView t=new TextView(this); t.setText("COG — COUNTRY OF GAMERS\nFloating Overlay"); t.setTextColor(Color.WHITE); t.setTextSize(24); t.setTypeface(null,1); root.addView(t,new LinearLayout.LayoutParams(-1,dp(90)));
    TextView info=new TextView(this); info.setText("Aktifkan izin 'Tampil di atas aplikasi lain', lalu tekan tombol Start Floating. Bubble COG akan muncul di atas aplikasi lain."); info.setTextColor(Color.LTGRAY); info.setTextSize(16); root.addView(info,new LinearLayout.LayoutParams(-1,dp(120)));
    Button perm=new Button(this); perm.setText("BUKA IZIN OVERLAY"); root.addView(perm,new LinearLayout.LayoutParams(-1,dp(56)));
    Button start=new Button(this); start.setText("START COG FLOATING"); root.addView(start,new LinearLayout.LayoutParams(-1,dp(56)));
    perm.setOnClickListener(v->{ if(Build.VERSION.SDK_INT>=23) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); });
    start.setOnClickListener(v->{ if(Build.VERSION.SDK_INT<23 || Settings.canDrawOverlays(this)){ startService(new Intent(this,FloatingService.class)); Toast.makeText(this,"COG floating aktif",Toast.LENGTH_SHORT).show(); } else Toast.makeText(this,"Aktifkan izin overlay dulu",Toast.LENGTH_LONG).show(); });
    setContentView(root);
  }
}
