# COG — Country of Gamers

Native Android floating overlay project.

Features:
- Floating COG bubble above other apps (requires overlay permission)
- Draggable floating panel
- Sensi Scale, Smoothness, Response Rate, Deadzone UI
- Presets UI
- Visual crosshair overlay with ON/OFF
- Macro Manager UI only; no automated game input

## Build on GitHub from a phone
1. Upload the contents of this repository to GitHub (do not upload the ZIP itself).
2. Open **Actions**.
3. Select **Build COG APK**.
4. Tap **Run workflow**.
5. Download artifact **COG-Floating-Crosshair-APK**.
